JARVIS HOLOGRAPHIC HAND CONTROL — PERFORMANCE + TRACKING UPDATE

This update improves gesture responsiveness and browser rendering performance.

WHAT CHANGED
- Webcam capture reduced to 480x270 for lower CPU load.
- MediaPipe tracking uses model_complexity=0 and slightly more forgiving confidence thresholds.
- The extra OpenCV preview window and per-frame landmark drawing are removed; the browser remains the main interface.
- Browser WebGL antialiasing is disabled and pixel ratio capped at 1.0 to reduce GPU work.
- Reduced decorative particle count and added a live browser FPS readout.
- Smoothed incoming landmarks while using delta-based pinch dragging to avoid the hologram jumping toward the center.
- Camera preview JPEG is sent at 10 FPS / lower quality to reduce encoding overhead; tracking data continues separately.

INSTALL
1. Stop the running backend with Ctrl+C.
2. Copy backend\main.py and frontend\index.html from this folder into your existing project, replacing those two files.
3. Keep your existing .venv and installed packages. Do not reinstall dependencies unless Python reports an import error.
4. From the project folder that contains backend and frontend, run your existing Python 3.11 environment, for example:
   & "..\..\jarvis_hand_interface\.venv\Scripts\python.exe" backend\main.py
   Adjust the relative path if your folder layout differs.
5. Open http://127.0.0.1:8000 and press Ctrl+F5.

GESTURES
- PINCH: grab and move the core using the midpoint between thumb and index finger.
- POINT: move index finger to rotate the core.
- OPEN PALM: toggle radial menu.
- SWIPE: switch data layers.
- TWO HANDS: zoom.

NOTES
- FPS displayed in the browser measures browser rendering FPS, not camera inference FPS.
- Lighting, camera quality, background clutter, and CPU/GPU performance affect tracking speed.
- Three.js loads from a CDN, so the browser needs internet access for the 3D engine.
